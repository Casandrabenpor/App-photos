import "./footer.css";

export const Footer = (prop) => {
  return (
    <div className={prop.className}>
        <p>Casandra Bennassar</p>
       <p>© 2023, all right reserved. </p>  
    </div>
  );
};
