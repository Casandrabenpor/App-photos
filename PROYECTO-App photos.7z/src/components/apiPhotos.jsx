

export const ApiPhotos = (props) =>{
    return (
        <>
        <img alt="random" src={props.photo.url}/>
        </>
    )
}