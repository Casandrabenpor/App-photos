import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { TopBar } from "../components/topBar";
import { useLocation } from "react-router-dom";
import { MainPhoto } from "../components/mainPhoto";
import { Search } from "../components/search";
import "../index.css";
import { ApiPhotos } from "../components/apiPhotos";
import { loadPhotos } from "../features/photosSlice";
import { Footer } from "../components/footer";

export const HomePage = () => {
    const location = useLocation();
    const dispatch = useDispatch();
    const photosListMac = useSelector((state) => state.photos.data);
    const [photos, setPhotos] = useState(photosListMac);
   
    useEffect(() => {
        console.log(photosListMac.length);
        if (photosListMac.length > 0) {
          console.log(photosListMac);
          setPhotos(photosListMac);
        }
      }, [photosListMac]);
    
      useEffect(() => {
        if (photos.length === 0) {
          setTimeout(() => {
            dispatch(loadPhotos());
          }, 2000);
        }
      }, [dispatch, photos.length]);
    
      const photosUI = () => {
        console.log("voy");
        let photosListObjects = [];
        console.log(photos);
        console.log(photosListMac);
        if (photos && Array.isArray(photos)) {
          photos.forEach((photo) => {
            photosListObjects.push(
              <>
                <ApiPhotos photo={photo} />
              </>
            );
          });
        }
        return photosListObjects;
      };
   
   
   
   
    return (
      <>
        <TopBar  location={location} />
        <MainPhoto className="MainPhoto"/>  
        <Search />
        <section className="reminderCardCollection">{photosUI()}</section>
        <Footer className="footer"/>
      </>
    );
  };
  