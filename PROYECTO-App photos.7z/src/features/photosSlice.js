import { createAsyncThunk, createSlice
 } from "@reduxjs/toolkit";

 export const loadPhotos = createAsyncThunk("photos/getPhotos", async () => {
    const data = await fetch(
        "https://api.unsplash.com/photos?client_id=c6-Zu3LQmTu2l5yW5lDfXq2L2Wpg1Q7f0kF286entVg&page=1&per_page=10"
    );
    const json = await data.json();
    let photos = json.map((photo)=> ({
        url: photo.urls.small
    }));
    return photos;
 });

 export const photosSlice = createSlice({
    name: "photos",
    initialState: {
      status: "fullfilled",
      data: [],
    },
    reducers: {
      createPhoto: (state, action) => {
        state.data.push(action.payload);
      },
      deletePhoto: (state, action) => {
        state.data.splice(
          state.data.findIndex((photos) => photos === action.payload)
        );
      },
    },
    extraReducers: (buider) => {
      buider
        .addCase(loadPhotos.pending, (state) => {
          state.data = "loading";
        })
        .addCase(loadPhotos.rejected, (state) => {
          state.status = "failed";
        })
        .addCase(loadPhotos.fulfilled, (state, action) => {
          state.status = "fulfilled";
          state.data = action.payload;
        });
    },
  });
  
  export const {createPhoto , deletePhoto} = photosSlice.actions;
  